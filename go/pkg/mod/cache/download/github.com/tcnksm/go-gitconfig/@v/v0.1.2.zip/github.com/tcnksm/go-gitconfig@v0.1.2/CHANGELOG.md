## 0.1.2 (2015-03-28)

Add new functions

### Added

- `GithubUser()` extracts `github.user` ([**dstokes**](https://github.com/dstokes)), [#5](https://github.com/tcnksm/go-gitconfig/pull/5/commits)

### Deprecated

- Nothing

### Removed

- Nothing

### Fixed

- Nothing


## 0.1.1 (2014-10-28)

Add new functions

### Added

- `GithubToken()` extracts `github.token` ([**@sona-tar**](https://github.com/sona-tar), [#3](https://github.com/tcnksm/go-gitconfig/pull/3))
- `Entire()` try to extract value from entire git config. It's able to extract values from included config ([**@sona-tar**](https://github.com/sona-tar), [#3](https://github.com/tcnksm/go-gitconfig/pull/3))

### Deprecated

- Nothing

### Removed

- Nothing

### Fixed

- Nothing


## 0.1.0 (2014-09-08)

Initial release

### Added

- Fundamental features

### Deprecated

- Nothing

### Removed

- Nothing

### Fixed

- Nothing


