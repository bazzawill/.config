# Symbols which can be used in PTerm

These symbols can be used in PTerm.\
Other symbols might not be displayed correctly on every operating system.\
With PTerm, we want to create a uniform styling, which is only possible if the output looks the same on every operating system and terminal.\
The icons listed here must be displayed correctly in the standard terminals in Windows, macOS and Linux.

``` 
☺ ☻ ♥ ♦ ♣ ♠
 • ◘ ○ ◙ ♂ ♀
 ♪ ♫ ☼ ► ◄ ↕
 ‼ ¶ ▬ ↨ ↑ ↓ →
 ← ∟ ↔ ▲ ▼ ø Ø
 × ƒ ® ¬ ½ ¼ ¡
 « » ░ ▒ ▓ │ ┤
 © ╣ ║ ╗ ╝ ¢ ¥
 ┐ └ ┴ ┬ ├ ─ ┼
 ╚ ╔ ╩ ╦ ╠ ═ ╬ 
¤ ┘ ┌ █ ▄ ¦ ▀
 µ þ ¯ ± ‗ ¾ ¶
 ÷ ° ¨ · ¹ ² ³
```