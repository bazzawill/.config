# Security Policy

## Supported Versions

Currently the last minor version v0.5.x is supported.

## Reporting a Vulnerability

Report a vulnerability by creating a Github issue at
<https://github.com/ulikunitz/xz/issues>. Expect a response in a week.
