# Release Notes v0.5.1

The release fixes a problem with 32-bit integers on 32-bit platforms.

Many thanks to Bruno Bigras, who reported the issue.
